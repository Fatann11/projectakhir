package com.example.projectakhir;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;

public class favorit extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.favorit);// Ganti nama layout jika perlu
        setTitle("Favorit"); // Judul di atas
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu); // menu.xml
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_menu1) {
            // Aksi untuk Menu 1
            return true;
        } else if (id == R.id.action_menu2) {
            // Aksi untuk Home
            finish(); // atau pindah ke MainActivity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
